from .load_segy import loadshots
